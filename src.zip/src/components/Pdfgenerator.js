import React from "react";
import pdfMake from "pdfmake/build/pdfmake";
import { loadMarathiFont } from "../utils/LoadPdfFonts";

function Pdfgenerator() {
  const data = [
    {
      standardMaster: { standard: "८वी" },
      division: { name: "अ" },
      staff: { fname: "श्री. अमित देशमुख" },
    },
    {
      standardMaster: { standard: "९वी" },
      division: { name: "ब" },
      staff: { fname: "श्रीमती. राधा पाटील" },
    },
    {
      standardMaster: { standard: "१०वी" },
      division: { name: "क" },
      staff: { fname: "श्री. विनोद शिंदे" },
    },
  ];

  const downloadReport = async () => {
    await loadMarathiFont(); // 👈 Load Marathi fonts before creating PDF

    const tableBody = [
      ["इयत्ता", "विभाग", "वर्गशिक्षक"],
      ...data.map((item) => [
        item?.standardMaster?.standard || "—",
        item?.division?.name || "—",
        item?.staff?.fname || "—",
      ]),
    ];

    const docDefinition = {
      content: [
        { text: "वर्गशिक्षक अहवाल", style: "header" },
        {
          table: {
            headerRows: 1,
            widths: ["*", "*", "*"],
            body: tableBody,
          },
        },
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
          alignment: "center",
          margin: [0, 0, 0, 10],
        },
      },
      defaultStyle: {
        font: "NotoSans", // 👈 Use Marathi-compatible font
      },
    };

    pdfMake.createPdf(docDefinition).download("वर्गशिक्षक_अहवाल.pdf");
  };

  return (
    <div className="text-center mt-4">
      <button className="btn btn-primary px-4 py-2 rounded-pill" onClick={downloadReport}>
        वर्गशिक्षक अहवाल डाउनलोड करा
      </button>
    </div>
  );
}

export default Pdfgenerator;
