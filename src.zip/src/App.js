import logo from './logo.svg';
import './App.css';
import React from 'react';
import Login from './pages/Login';
import 'bootstrap/dist/css/bootstrap.min.css';
import NewSchool from './components/NewSchool';
import NavBarS from './components/NavBarS';
import AddSchoolInfo from './components/AddSchoolInfo';
import AddStaffMember from './components/AddStaffMember';
import AddClass from './components/AddClass';
import AddClassTeacher from './components/AddClassTeacher';
import Pdfgenerator from './components/Pdfgenerator';

function App() {
  return (
    <>
      {/* <NavBarS /> */}
      <div style={{"min-height": "45px"}}></div>
      {/* <NewSchool /> */}
      {/* <AddSchoolInfo/> */}
        {/* <AddStaffMember/> */}
        {/* <AddClass/> */}
        {/* <AddClassTeacher/> */}
        <Pdfgenerator/>
      {/* <Login /> */}
    </>
  );
}

export default App;
