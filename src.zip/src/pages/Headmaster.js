import React from 'react'

function Headmaster() {
  return (
    <div>
      
    </div>
  )
}

export default Headmaster
