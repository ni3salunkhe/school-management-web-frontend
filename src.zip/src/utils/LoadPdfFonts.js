import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";

// Load pdfMake virtual file system first
pdfMake.vfs = pdfFonts.vfs;

export const loadMarathiFont = async () => {
  // Fetch custom TTFs from the public/fonts directory
  const fetchFontAsBase64 = async (fontPath) => {
    const response = await fetch(fontPath);
    const buffer = await response.arrayBuffer();
    return btoa(
      new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), "")
    );
  };

  // ✅ Make sure these files exist in `public/fonts/`
  const regular = await fetchFontAsBase64("/Assets/fonts/NotoSansDevanagari-Regular.ttf");
  const bold = await fetchFontAsBase64("/Assets/fonts/NotoSansDevanagari-Bold.ttf");
  

  // ✅ Assign them to pdfMake.vfs safely
  pdfMake.vfs["NotoSansDevanagari-Regular.ttf"] = regular;
  pdfMake.vfs["NotoSansDevanagari-Bold.ttf"] = bold;

  // Register the font with pdfMake
  pdfMake.fonts = {
    ...pdfMake.fonts,
    NotoSans: {
      normal: "NotoSansDevanagari-Regular.ttf",
      bold: "NotoSansDevanagari-Bold.ttf",
      italics: "NotoSansDevanagari-Regular.ttf",
      bolditalics: "NotoSansDevanagari-Bold.ttf",
    },
  };
};
